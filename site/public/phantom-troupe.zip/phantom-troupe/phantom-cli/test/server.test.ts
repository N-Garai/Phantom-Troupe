import { test } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import net from "node:net";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), "phantom-server-test-"));
process.env.PHANTOM_HOME = TMP;

import { createServer } from "../dist/server.js";

async function fetchJson(port: number, pathname: string, opts: Record<string, unknown> = {}): Promise<{ status: number; body: unknown }> {
  const method = (opts.method ?? "GET") as string;
  const body = opts.body ? JSON.stringify(opts.body) : undefined;
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: "127.0.0.1",
        port,
        path: pathname,
        method,
        headers: body ? { "content-type": "application/json", "content-length": Buffer.byteLength(body) } : {},
        timeout: 3000,
      },
      (res) => {
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => resolve({ status: res.statusCode ?? 0, body: data ? JSON.parse(data) : {} }));
      },
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
    if (body) req.write(body);
    req.end();
  });
}

test("server: /api/health returns ok", async (t) => {
  const server = createServer();
  const port = await new Promise<number>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve((server.address() as net.AddressInfo).port));
  });
  try {
    const r = await fetchJson(port, "/api/health");
    assert.strictEqual(r.status, 200, "health should be 200");
    assert.strictEqual((r.body as Record<string, unknown>).ok, true, "health ok should be true");
  } finally {
    server.close();
    await new Promise((r) => setTimeout(r, 100));
  }
});

test("server: /api/exec runs a benign command", async (t) => {
  const server = createServer();
  const port = await new Promise<number>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve((server.address() as net.AddressInfo).port));
  });
  try {
    const r = await fetchJson(port, "/api/exec", { method: "POST", body: { cmd: "echo hello-phantom" } });
    assert.strictEqual(r.status, 200, "exec should be 200");
    const body = r.body as Record<string, unknown>;
    assert.strictEqual(body.guarded, undefined, "benign command should not be guarded");
    assert.ok((body.stdout as string).includes("hello-phantom"), "should echo back");
    assert.strictEqual(body.exit, 0, "exit should be 0");
  } finally {
    server.close();
    await new Promise((r) => setTimeout(r, 100));
  }
});

test("server: /api/exec guards rm -rf without confirm", async (t) => {
  const server = createServer();
  const port = await new Promise<number>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve((server.address() as net.AddressInfo).port));
  });
  try {
    const r = await fetchJson(port, "/api/exec", { method: "POST", body: { cmd: "rm -rf /" } });
    assert.strictEqual(r.status, 200, "guard response should be 200");
    const body = r.body as Record<string, unknown>;
    assert.strictEqual(body.guarded, true, "should be guarded");
    assert.strictEqual(body.severity, "high", "should be high severity");
    assert.strictEqual(body.exit, -1, "should not have run (exit -1)");
    assert.strictEqual(body.stdout, "", "no stdout");
    assert.strictEqual(body.stderr, "", "no stderr");
  } finally {
    server.close();
    await new Promise((r) => setTimeout(r, 100));
  }
});

test("server: /api/exec runs rm -rf with confirm", async (t) => {
  const server = createServer();
  const port = await new Promise<number>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve((server.address() as net.AddressInfo).port));
  });
  try {
    const r = await fetchJson(port, "/api/exec", { method: "POST", body: { cmd: "echo confirmed-from-grave", confirm: true } });
    assert.strictEqual(r.status, 200, "confirmed exec should be 200");
    const body = r.body as Record<string, unknown>;
    assert.strictEqual(body.guarded, undefined, "confirmed command should not be guarded");
    assert.ok(body.exit !== undefined, "should have an exit code");
  } finally {
    server.close();
    await new Promise((r) => setTimeout(r, 100));
  }
});

test("server: /api/state returns roster", async (t) => {
  const server = createServer();
  const port = await new Promise<number>((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve((server.address() as net.AddressInfo).port));
  });
  try {
    const r = await fetchJson(port, "/api/state");
    assert.strictEqual(r.status, 200, "state should be 200");
    const body = r.body as Record<string, unknown>;
    assert.ok("provider" in body, "should have provider");
    assert.ok("corpses" in body, "should have corpses count");
    assert.ok("graves" in body, "should have graves count");
  } finally {
    server.close();
    await new Promise((r) => setTimeout(r, 100));
  }
});

// Cleanup temp dir on finish
test.after(() => {
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
});
