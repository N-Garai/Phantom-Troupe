"use client";

import type { CSSProperties } from "react";

type BatDef = {
  top: string;
  left: string;
  scale: number;
  dur: number;
  delay: number;
  wave: number;
  amp: string;
  flap: number;
  opacity: number;
  toward?: boolean;
};

/* A larger colony of bats — some crossing the sky, others diving toward
 * the viewer for a more immersive horror feel. */
const BATS: BatDef[] = [
  // crossing bats (right → left)
  { top: "14%", left: "100%", scale: 1, dur: 16, delay: 0.5, wave: 3.6, amp: "-26px", flap: 0.4, opacity: 0.9 },
  { top: "22%", left: "100%", scale: 0.65, dur: 22, delay: 4, wave: 4.4, amp: "-18px", flap: 0.34, opacity: 0.6 },
  { top: "10%", left: "100%", scale: 0.8, dur: 19, delay: 8, wave: 3.1, amp: "-32px", flap: 0.46, opacity: 0.75 },
  { top: "30%", left: "100%", scale: 0.55, dur: 24, delay: 12, wave: 5, amp: "-14px", flap: 0.3, opacity: 0.55 },
  { top: "16%", left: "100%", scale: 0.7, dur: 17, delay: 16, wave: 3.9, amp: "-24px", flap: 0.42, opacity: 0.7 },
  // bats diving toward the screen (center-ish)
  { top: "8%", left: "42%", scale: 0.25, dur: 10, delay: 1, toward: true, wave: 3, amp: "-20px", flap: 0.38, opacity: 0.8 },
  { top: "12%", left: "58%", scale: 0.35, dur: 11, delay: 3, toward: true, wave: 3.4, amp: "-16px", flap: 0.4, opacity: 0.85 },
  { top: "6%", left: "30%", scale: 0.2, dur: 12, delay: 5, toward: true, wave: 2.8, amp: "-28px", flap: 0.36, opacity: 0.7 },
  { top: "14%", left: "72%", scale: 0.4, dur: 10.5, delay: 6.5, toward: true, wave: 3.2, amp: "-22px", flap: 0.44, opacity: 0.8 },
];

function BatSvg() {
  return (
    <svg viewBox="0 0 64 28" className="h-auto w-full" style={{ filter: "drop-shadow(0 0 6px rgba(0,0,0,0.9))" }}>
      <g fill="#050309">
        {/* left wing */}
        <path d="M30 14 C24 6 14 2 4 6 C10 8 12 12 10 16 C16 14 20 15 22 18 C24 16 27 15 30 16 Z" />
        {/* right wing */}
        <path d="M34 14 C40 6 50 2 60 6 C54 8 52 12 54 16 C48 14 44 15 42 18 C40 16 37 15 34 16 Z" />
        {/* body + ears */}
        <ellipse cx="32" cy="15" rx="4.6" ry="7" />
        <path d="M28 9 L27 3 L31 7 Z M36 9 L37 3 L33 7 Z" />
      </g>
      {/* tiny eyes catch the moonlight */}
      <circle cx="30.4" cy="12.6" r="0.8" fill="#74f2a4" opacity="0.85" />
      <circle cx="33.6" cy="12.6" r="0.8" fill="#74f2a4" opacity="0.85" />
    </svg>
  );
}

/**
 * A colony of bats: some cross the sky on lazy sine waves, others swoop
 * toward the viewer (growing larger) for a startling, immersive effect.
 * Pure CSS on three nested layers: path (X traverse) → wave (Y bob) → flap (wingbeat squash).
 */
export function Bats({ className }: { className?: string }) {
  return (
    <div className={`bat-colony ${className ?? ""}`} aria-hidden>
      {BATS.map((b, i) => (
        <div
          key={i}
          className={`bat-path ${b.toward ? "bat-toward" : ""}`}
          style={{
            top: b.top,
            left: b.toward ? b.left : "100%",
            animationDelay: `${b.delay}s`,
            animationDuration: `${b.dur}s`,
            opacity: String(b.opacity),
            transform: `scale(${b.scale})`,
          } as CSSProperties}
          aria-hidden
        >
          <div
            className="bat-wave"
            style={{ ["--wave"]: `${b.wave}s`, ["--amp"]: b.amp, opacity: b.opacity } as CSSProperties}
          >
            <div className="bat-flap" style={{ ["--flap"]: `${b.flap}s` } as CSSProperties}>
              <BatSvg />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
