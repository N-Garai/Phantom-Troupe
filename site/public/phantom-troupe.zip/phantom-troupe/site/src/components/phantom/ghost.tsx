"use client";

import { useEffect, useRef } from "react";

type GhostProps = {
  className?: string;
  /** parallax strength (px). 0 disables mouse-follow */
  parallax?: number;
};

/** The troupe's mascot: a spectral wispy ghost with glowing eyes,
 *  tattered hem, and an eerie internal glow. */
export function Ghost({ className, parallax = 18 }: GhostProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!parallax) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    let tx = 0, ty = 0, cx = 0, cy = 0;
    const onMove = (e: MouseEvent) => {
      const nx = e.clientX / window.innerWidth - 0.5;
      const ny = e.clientY / window.innerHeight - 0.5;
      tx = nx * parallax;
      ty = ny * parallax * 0.6;
    };
    const loop = () => {
      cx += (tx - cx) * 0.05;
      cy += (ty - cy) * 0.05;
      el.style.transform = `translate3d(${cx}px, ${cy}px, 0)`;
      raf = requestAnimationFrame(loop);
    };
    window.addEventListener("mousemove", onMove);
    raf = requestAnimationFrame(loop);
    return () => {
      window.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
    };
  }, [parallax]);

  return (
    <div ref={ref} className={className} aria-hidden>
      <div className="ghost-float relative" style={{ perspective: "700px" }}>
        <div className="ghost-tilt relative">
          {/* spectral outer glow */}
          <div className="absolute inset-0 -z-10 rounded-full bg-[radial-gradient(circle_at_50%_40%,rgba(116,242,164,0.3),transparent_65%)] blur-2xl" />
          <div className="absolute inset-0 -z-10 rounded-full bg-[radial-gradient(circle_at_50%_50%,rgba(247,155,46,0.15),transparent_70%)] blur-3xl" />

          <svg viewBox="0 0 220 280" className="ghost-glow-pulse h-auto w-full drop-shadow-[0_0_40px_rgba(116,242,164,0.3)]">
            <defs>
              <linearGradient id="ghostBody2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="rgba(233,225,210,0.95)" />
                <stop offset="40%" stopColor="rgba(233,225,210,0.6)" />
                <stop offset="75%" stopColor="rgba(233,225,210,0.25)" />
                <stop offset="100%" stopColor="rgba(233,225,210,0.04)" />
              </linearGradient>
              <filter id="ghostBlur" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* main spectral body — wispy, tattered bottom */}
            <path
              d="M110 22c-48 0-78 38-78 88 0 34 14 52 26 68 8 12 16 22 18 36 1 8 9 12 16 12h52c7 0 15-4 16-12 2-14 10-24 18-36 12-16 26-34 26-68 0-50-30-88-78-88z"
              fill="url(#ghostBody2)"
              filter="url(#ghostBlur)"
            />
            {/* hollow eye sockets */}
            <ellipse cx="82" cy="110" rx="11" ry="16" fill="#050309" opacity="0.95" />
            <ellipse cx="138" cy="110" rx="11" ry="16" fill="#050309" opacity="0.95" />
            {/* glowing eye pupils */}
            <circle cx="84" cy="106" r="4" fill="#74f2a4" />
            <circle cx="140" cy="106" r="4" fill="#74f2a4" />
            <circle cx="84" cy="106" r="1.5" fill="#fff" opacity="0.9" />
            <circle cx="140" cy="106" r="1.5" fill="#fff" opacity="0.9" />
            {/* sad, open mouth */}
            <path d="M92 154c8 8 14 11 22 11s14-3 22-11" stroke="#050309" strokeWidth="6" strokeLinecap="round" fill="none" opacity="0.85" />
            {/* tattered folds and texture */}
            <path d="M48 228c10 12 22 14 34 8m68 8c10-8 20-8 28 2m-104-22c8 10 18 12 28 6m60 8c8-8 16-10 24-2" stroke="rgba(233,225,210,0.55)" strokeWidth="5" strokeLinecap="round" fill="none" />
          </svg>
        </div>
      </div>
    </div>
  );
}
