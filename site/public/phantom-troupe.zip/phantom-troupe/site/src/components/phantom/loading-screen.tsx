"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";

type Phase = "forest" | "bats" | "title" | "smoke-out" | "exit";

const SESSION_KEY = "phantom-loader-seen";

/* ---- dark forest silhouettes ---- */
function ForestLayer({
  path,
  fill,
  className,
  bottom,
}: {
  path: string;
  fill: string;
  className?: string;
  bottom?: string;
}) {
  return (
    <svg
      viewBox="0 0 1440 320"
      preserveAspectRatio="none"
      className={`absolute left-0 w-full ${className ?? ""}`}
      style={{ bottom: bottom ?? 0, transform: "scaleX(-1)" }}
      aria-hidden
    >
      <path d={path} fill={fill} />
    </svg>
  );
}

/* ---- one bat flying toward the viewer (gets larger, closer) ---- */
function BatToward({
  delay,
  dur,
  scale,
  top,
  left,
  opacity,
}: {
  delay: number;
  dur: number;
  scale: number;
  top: string;
  left: string;
  opacity: number;
}) {
  return (
    <div
      className="bat-toward absolute"
      style={{
        top,
        left,
        animationDelay: `${delay}s`,
        animationDuration: `${dur}s`,
        opacity: String(opacity),
        transform: `scale(${scale})`,
      } as React.CSSProperties}
      aria-hidden
    >
      <svg viewBox="0 0 64 28" className="h-auto w-full" style={{ filter: "drop-shadow(0 0 8px rgba(0,0,0,0.8))" }}>
        <g fill="#050309">
          <path d="M30 14 C24 6 14 2 4 6 C10 8 12 12 10 16 C16 14 20 15 22 18 C24 16 27 15 30 16 Z" />
          <path d="M34 14 C40 6 50 2 60 6 C54 8 52 12 54 16 C48 14 44 15 42 18 C40 16 37 15 34 16 Z" />
          <ellipse cx="32" cy="15" rx="4.6" ry="7" />
          <path d="M28 9 L27 3 L31 7 Z M36 9 L37 3 L33 7 Z" />
        </g>
        <circle cx="30.4" cy="12.6" r="0.8" fill="#74f2a4" opacity="0.85" />
        <circle cx="33.6" cy="12.6" r="0.8" fill="#74f2a4" opacity="0.85" />
      </svg>
    </div>
  );
}

/* ---- smoke puff that drifts and expands ---- */
function SmokePuff({
  delay,
  dur,
  x,
  y,
  size,
  rotate,
}: {
  delay: number;
  dur: number;
  x: string;
  y: string;
  size: number;
  rotate: number;
}) {
  return (
    <div
      className="smoke-puff absolute"
      style={{
        left: x,
        top: y,
        width: size,
        height: size * 0.55,
        animationDelay: `${delay}s`,
        animationDuration: `${dur}s`,
        transform: `rotate(${rotate}deg)`,
      } as React.CSSProperties}
      aria-hidden
    />
  );
}

/* ---- one letter materializing from smoke ---- */
function SmokeLetter({
  ch,
  delay,
  phase,
  reduce,
}: {
  ch: string;
  delay: number;
  phase: Phase;
  reduce: boolean;
}) {
  const visible = phase === "title" || phase === "smoke-out";
  const gone = phase === "smoke-out" || phase === "exit";
  const shown = visible && !gone;

  if (reduce) {
    return (
      <motion.span
        aria-hidden
        className="inline-block"
        initial={{ opacity: 0 }}
        animate={{ opacity: shown ? 1 : 0 }}
        transition={{ duration: 0.4, delay: shown ? delay * 0.5 : 0 }}
      >
        {ch === " " ? "\u00A0" : ch}
      </motion.span>
    );
  }

  return (
    <motion.span
      aria-hidden
      className="inline-block will-change-transform"
      initial={{
        opacity: 0,
        y: 30,
        filter: "blur(20px)",
        scale: 1.3,
        rotateX: 45,
      }}
      animate={
        gone
          ? {
              opacity: 0,
              y: -60,
              filter: "blur(24px)",
              scale: 0.6,
              rotateX: -45,
              x: 12,
            }
          : shown
            ? {
                opacity: 0.95,
                y: 0,
                filter: "blur(0px)",
                scale: 1,
                rotateX: 0,
                x: 0,
              }
            : {}
      }
      transition={
        gone
          ? {
              duration: 1.2,
              delay: delay * 0.35,
              ease: [0.4, 0, 0.6, 1],
            }
          : {
              duration: 1.1,
              delay,
              ease: [0.16, 1, 0.3, 1],
            }
      }
    >
      {ch === " " ? "\u00A0" : ch}
    </motion.span>
  );
}

export function LoadingScreen() {
  const reduce = useReducedMotion();
  const [visible, setVisible] = useState(false);
  const [phase, setPhase] = useState<Phase>("forest");
  const [soundOn, setSoundOn] = useState(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const hasSeen = useRef(false);

  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  const at = useCallback((ms: number, fn: () => void) => {
    timers.current.push(setTimeout(fn, ms));
  }, []);

  /* ---- show the loader once per session, then run the cinematic rite ---- */
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(SESSION_KEY)) {
      // already seen this session — still let it flash once on hard reload guard
      setVisible(false);
      return;
    }
    sessionStorage.setItem(SESSION_KEY, "1");
    hasSeen.current = true;

    document.body.style.overflow = "hidden";
    setVisible(true);
    setPhase("forest");

    const total = reduce ? 2600 : 7200;

    if (reduce) {
      at(400, () => setPhase("title"));
      at(1600, () => setPhase("smoke-out"));
      at(2200, () => setPhase("exit"));
    } else {
      at(600, () => setPhase("bats")); // bats start swarming
      at(1700, () => setPhase("title")); // name emerges from smoke
      at(4100, () => setPhase("smoke-out")); // name dissolves into smoke
      at(5200, () => setPhase("exit")); // overlay leaves
    }

    at(total + 600, () => {
      document.body.style.overflow = "";
      setVisible(false);
    });

    return clearTimers;
  }, [at, reduce]);

  useEffect(() => {
    if (!visible) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === "Enter" || e.key === " ") {
        clearTimers();
        setPhase("exit");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [visible]);

  const done = phase === "exit";
  const showTitle = phase === "title" || phase === "smoke-out";
  const showBats = phase === "bats" || phase === "title" || phase === "smoke-out";

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="loader"
          data-testid="loading-screen"
          className="loader-stage fixed inset-0 z-[200] cursor-pointer overflow-hidden bg-void"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02, filter: "blur(8px)" }}
          transition={{
            duration: reduce ? 0.3 : 0.7,
            ease: [0.4, 0, 0.2, 1],
          }}
          role="status"
          aria-label="Summoning the Phantom Troupe"
          onClick={() => {
            clearTimers();
            setPhase("exit");
          }}
        >
          {/* ================= deep void background ================= */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,#0a0616_25,#050309_70%_100%)]" />
          <div className="absolute inset-0 bg-[linear-gradient(180deg,#020105_0%,#080410_45%,#050309_100%)]" />

          {/* ================= dark forest layers (back to front) ================= */}
          <ForestLayer
            path="M0 320 L60 250 L150 300 L280 240 L420 290 L580 230 L740 280 L920 220 L1080 260 L1220 210 L1360 250 L1440 200 L1440 320 Z"
            fill="#030206"
            bottom={0}
          />
          <ForestLayer
            path="M0 300 L80 220 L200 270 L350 190 L520 250 L700 180 L900 240 L1100 170 L1280 220 L1440 160 L1440 300 Z"
            fill="#0a0614"
            bottom={-10}
          />
          <ForestLayer
            path="M0 280 L100 180 L260 240 L420 160 L600 220 L780 150 L960 210 L1140 140 L1320 190 L1440 130 L1440 280 Z"
            fill="#100a1e"
            bottom={-24}
          />

          {/* ================= heavy smoke everywhere ================= */}
          <div className="absolute inset-0 pointer-events-none">
            {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
              <SmokePuff
                key={i}
                delay={i * 0.9}
                dur={14 + i * 2}
                x={`-${10 + i * 12}%`}
                y={`${40 + i * 8}%`}
                size={420 + i * 180}
                rotate={-15 + i * 8}
              />
            ))}
            {[0, 1, 2, 3].map((i) => (
              <SmokePuff
                key={`r${i}`}
                delay={2 + i * 1.1}
                dur={16 + i * 3}
                x={`85%`}
                y={`${20 + i * 15}%`}
                size={300 + i * 120}
                rotate={20 - i * 6}
              />
            ))}
          </div>

          {/* rolling ground smoke */}
          <div className="absolute bottom-0 left-0 w-full h-[35%] pointer-events-none">
            <div
              className="smoke-puff absolute"
              style={{
                left: "0",
                bottom: "0",
                width: "200%",
                height: "140%",
                animationDelay: "0s",
                animationDuration: "12s",
                transform: "rotate(-5deg) scaleX(1.4)",
              } as React.CSSProperties}
              aria-hidden
            />
            <div
              className="smoke-puff absolute"
              style={{
                left: "-20%",
                bottom: "-5%",
                width: "240%",
                height: "160%",
                animationDelay: "4s",
                animationDuration: "15s",
                transform: "rotate(8deg) scaleX(1.6)",
              } as React.CSSProperties}
              aria-hidden
            />
          </div>

          {/* ================= bats moving toward the screen ================= */}
          {showBats && (
            <div className="absolute inset-0 pointer-events-none">
              <BatToward delay={0.2} dur={10} scale={0.35} top="12%" left="8%" opacity={0.85} />
              <BatToward delay={1.4} dur={11} scale={0.5} top="28%" left="22%" opacity={0.9} />
              <BatToward delay={2.6} dur={9} scale={0.28} top="6%" left="45%" opacity={0.7} />
              <BatToward delay={3.8} dur={12} scale={0.62} top="18%" left="62%" opacity={0.95} />
              <BatToward delay={5.0} dur={10} scale={0.42} top="34%" left="78%" opacity={0.8} />
              <BatToward delay={6.2} dur={13} scale={0.55} top="10%" left="90%" opacity={0.75} />
              <BatToward delay={7.4} dur={11} scale={0.38} top="42%" left="5%" opacity={0.82} />
              <BatToward delay={8.6} dur={10} scale={0.48} top="22%" left="33%" opacity={0.88} />
            </div>
          )}

          {/* ================= moon behind smoke ================= */}
          <div
            className="absolute right-[10%] top-[8%] h-24 w-24 sm:h-32 sm:w-32 rounded-full"
            style={{
              background: "radial-gradient(circle at 40% 40%, #fdf6e3 0%, #e7d9b8 40%, #b9a67e 70%, #5a4a3a 100%)",
              boxShadow:
                "0 0 50px 20px rgba(255, 236, 190, 0.15), 0 0 120px 60px rgba(247,155,46,0.08)",
              opacity: 0.85,
            }}
            aria-hidden
          />
          <div
            className="absolute right-[7%] top-[5%] h-36 w-36 sm:h-44 sm:w-44 rounded-full blur-2xl"
            style={{
              background: "radial-gradient(circle, rgba(253,246,227,0.12), transparent 60%)",
              opacity: 0.6,
            }}
            aria-hidden
          />

          {/* ================= PHANTOM TROUPE name — smoke reveal ================= */}
          <div
            className={`absolute inset-x-0 bottom-[20%] text-center pointer-events-none ${showTitle ? "opacity-100" : "opacity-0"}`}
            style={{
              transition: "opacity 1.2s cubic-bezier(0.4, 0, 0.6, 1)",
            }}
            aria-hidden
          >
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: showTitle ? 0.7 : 0, y: 0 }}
              transition={{ duration: 0.8, delay: showTitle ? 0 : 0 }}
              className="mb-4 font-[family-name:var(--font-geist-mono)] text-[10px] uppercase tracking-[0.8em] text-ash/60 sm:text-[11px]"
            >
              the veil is lifting…
            </motion.p>
            <h1
              className="font-[family-name:var(--font-cinzel)] text-[14vw] font-black leading-[0.9] text-bone sm:text-7xl md:text-8xl tracking-[0.05em]"
              aria-label="Phantom Troupe"
            >
              <span className="block">
                {Array.from("PHANTOM").map((ch, i) => (
                  <SmokeLetter key={i} ch={ch} delay={i * 0.13} phase={phase} reduce={reduce} />
                ))}
              </span>
              <span className="mt-1 block text-marigold tracking-[0.12em]">
                {Array.from("TROUPE").map((ch, i) => (
                  <SmokeLetter key={i} ch={ch} delay={0.85 + i * 0.13} phase={phase} reduce={reduce} />
                ))}
              </span>
            </h1>
            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: showTitle ? 0.55 : 0, y: 0 }}
              transition={{ duration: 0.8, delay: 2.4 }}
              className="mt-6 font-[family-name:var(--font-geist-mono)] text-[11px] uppercase tracking-[0.5em] text-spectre/70 sm:text-[12px]"
            >
              every command leaves a corpse
            </motion.p>
          </div>

          {/* ================= skip hint ================= */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.45 }}
            transition={{ delay: 1.6, duration: 0.8 }}
            className="absolute bottom-8 right-8 font-[family-name:var(--font-geist-mono)] text-[10px] uppercase tracking-[0.3em] text-ash"
          >
            click anywhere to pass on
          </motion.p>

          {/* ================= film grain + vignette ================= */}
          <div className="film-grain pointer-events-none absolute inset-0 z-10" aria-hidden />
          <div className="vignette pointer-events-none absolute inset-0 z-10" aria-hidden />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
